VERSION = "0.10.0"
APP_ID = "com.jgu.LinuxSkyTrack"
APP_NAME = "SkyTrack"
REPO_URL = "https://github.com/0-fasety-akademia/linux-skytrack"
