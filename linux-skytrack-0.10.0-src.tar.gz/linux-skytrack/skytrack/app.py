"""SkyTrack application: actions, notifications, About."""
import os
import sys

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from . import db, geo, stats, theme
from .airports import AirportDB, default_path
from .version import APP_ID, APP_NAME, REPO_URL, VERSION
from .i18n import _

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))



class SkyTrackApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        GLib.set_application_name(APP_NAME)
        self.window = None
        self.web_dir = os.path.join(BASE_DIR, "web")
        self.icon_dir = os.path.join(BASE_DIR, "icons")
        self.template_dir = os.path.join(BASE_DIR, "templates")
        self.add_main_option("add", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Open the add-trip dialog", None)
        self._add_on_start = False

    # Lifecycle -------------------------------------------------------------------------
    def do_handle_local_options(self, options):
        if options.contains("add"):
            self.register(None)
            if self.get_is_remote():
                self.activate_action("add-trip", None)
                return 0
            self._add_on_start = True
        return -1

    def do_startup(self):
        Adw.Application.do_startup(self)
        self.settings = db.Settings()
        self.store = db.TripStore()
        self.airports = AirportDB(default_path())

        display = Gdk.Display.get_default()
        icons = Gtk.IconTheme.get_for_display(display)
        for sub in ("scalable/apps", "symbolic/apps"):
            path = os.path.join(self.icon_dir, "hicolor", sub)
            if os.path.isdir(path):
                icons.add_search_path(path)
        if self.settings["theme"] not in theme.THEMES:
            self.settings["theme"] = "system"
        theme.apply(self.settings["theme"])

        for name, cb, accels in (
            ("add-trip", lambda *_: self._show(add=True), ["<Control>n"]),
            ("show", lambda *_: self._show(), []),
            ("show-trips", lambda *_: self._show(page="trips"), ["<Control>1"]),
            ("show-stats", lambda *_: self._show(page="stats"), ["<Control>3"]),
            ("about", self._on_about, []),
            ("open-data", self._on_open_data, []),
            ("import", lambda *_: (self._show(), self.window.when_unlocked(self.window.import_csv)),
             ["<Control>i"]),
            ("export", lambda *_: (self._show(), self.window.when_unlocked(self.window.export_csv)),
             ["<Control>e"]),
            ("save-template", lambda *_: (self._show(), self.window.when_unlocked(self.window.save_template)),
             []),
            ("show-plans", lambda *_: self._show(page="plans"), ["<Control>2"]),
            ("quit", lambda *_: self.quit_all(), ["<Control>q"]),
            ("lock", lambda *_: self.window and self.window.lock(), ["<Control>l"]),
            ("change-password", lambda *_: self.window and self.window.change_password(), []),
        ):
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", cb)
            self.add_action(act)
            if accels:
                self.set_accels_for_action(f"app.{name}", accels)
        theme_act = Gio.SimpleAction.new_stateful("theme", GLib.VariantType.new("s"),
                                                  GLib.Variant.new_string(self.settings["theme"]))
        theme_act.connect("change-state", self._on_theme)
        self.add_action(theme_act)
        GLib.timeout_add_seconds(300, self._check_upcoming)
        GLib.timeout_add_seconds(5, lambda: (self._check_upcoming(), False)[1])
        self.set_accels_for_action("window.close", ["<Control>w"])


    def do_activate(self):
        if self.window is None:
            from .window import MainWindow
            self.window = MainWindow(self)
        add, self._add_on_start = self._add_on_start, False
        self._show(add=add)

    def quit_all(self):
        if getattr(self, "_quitting", False):
            return
        self._quitting = True
        if self.window:
            self.window.save_state()
        self.quit()

    def _show(self, add=False, page=None):
        if self.window is None:
            self.activate()
            if self.window is None:
                return
        self.window.set_visible(True)
        self.window.present()
        win = self.window
        if page:
            win.when_unlocked(lambda: win.stack.set_visible_child_name(page))
        if add:
            win.when_unlocked(lambda: (win.stack.set_visible_child_name("trips"), win.add_trip()))
        if win.locked:
            win.lock_page.focus_first()

    def _check_upcoming(self):
        """Notify once when a planned flight departs within 24 hours (not while locked)."""
        if not self.window or self.window.locked:
            return True
        from datetime import datetime
        from zoneinfo import ZoneInfo
        notified = list(self.settings["notified"] or [])
        changed = False
        for i in stats.planned(self.window.all_infos):
            t = i.trip
            dep = geo.local_dt(t.dep_date, t.dep_time or "00:00", i.origin.tz)
            if not dep:
                continue
            hours = (dep - datetime.now(ZoneInfo(i.origin.tz))).total_seconds() / 3600
            key = f"{t.id}:{t.dep_date}:{t.dep_time}"
            if 0 < hours <= 24 and key not in notified:
                when = f"{stats.nice_date(t.dep_date, True)}" + (f", {t.dep_time}" if t.dep_time else "")
                self.notify(f"upcoming-{t.id}", _('Lot {0}: {1} → {2}').format(i.countdown, t.origin, t.dest),
                            f"{i.origin.short} → {i.dest.short} · {when}\n"
                            f"{geo.fmt_km(i.km)} · {geo.fmt_duration(i.minutes, i.approx)}")
                notified.append(key)
                changed = True
        if changed:
            self.settings["notified"] = notified[-200:]
        return True

    def _on_theme(self, action, value):
        name = value.get_string()
        if name not in theme.THEMES:
            return
        action.set_state(value)
        self.settings["theme"] = name
        theme.apply(name)
        if self.window:
            self.window.apply_theme(name)

    # Misc ------------------------------------------------------------------------------------
    def notify(self, nid, title, body):
        n = Gio.Notification.new(title)
        n.set_body(body)
        n.set_icon(Gio.ThemedIcon.new("linux-skytrack"))
        n.set_default_action("app.show")
        self.send_notification(nid, n)

    def _on_open_data(self, *_a):
        if self.window and self.window.locked:
            return
        Gio.AppInfo.launch_default_for_uri(GLib.filename_to_uri(db.data_dir(), None), None)

    def _on_about(self, *_a):
        about = Adw.AboutDialog(
            application_name=APP_NAME,
            application_icon="linux-skytrack",
            developer_name="Created by: JGu\nSupported by Claude",
            version=VERSION,
            website=REPO_URL,
            issue_url=REPO_URL + "/issues",
            comments=_('Dziennik lotów dla Ubuntu: Twoje podróże na mapie, kilometry odbytych lotów i statystyki rok / miesiąc / dzień. Zdjęcia z podróży z Linux iCloud Photos.'),
            license_type=Gtk.License.MIT_X11,
            developers=["JGu"],
        )
        about.add_credit_section("Supported by", ["Claude"])
        about.add_legal_section(_('Dane lotnisk — OurAirports'), None, Gtk.License.CUSTOM,
                                "Public domain. https://ourairports.com/data/")
        about.add_legal_section("Leaflet", "© 2010–2023 Volodymyr Agafonkin, © 2010–2011 CloudMade",
                                Gtk.License.BSD, None)
        about.add_legal_section(_('Mapa — OpenStreetMap'), "© OpenStreetMap contributors",
                                Gtk.License.CUSTOM, _('Dane mapy na licencji ODbL. https://www.openstreetmap.org/copyright'))
        about.add_legal_section(_('Zdjęcia satelitarne — Esri World Imagery'),
                                "Esri, Maxar, Earthstar Geographics, GIS User Community",
                                Gtk.License.CUSTOM, _('Użycie zgodnie z warunkami Esri.'))
        about.present(self.window)


def main():
    app = SkyTrackApp()
    return app.run(sys.argv)
